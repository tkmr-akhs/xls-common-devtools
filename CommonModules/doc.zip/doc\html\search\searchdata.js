var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuw",
  1: "acdefiloptuw",
  2: "cs",
  3: "abcdefghijlmnoprstuw",
  4: "abcdefghimoprstw",
  5: "abcdefgilmprstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "properties"
};

var indexSectionLabels =
{
  0: "全て",
  1: "クラス",
  2: "名前空間",
  3: "関数",
  4: "変数",
  5: "プロパティ"
};

