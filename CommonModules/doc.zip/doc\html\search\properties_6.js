var searchData=
[
  ['getreadlock_0',['GetReadLock',['../interface_class_1_1_i_text_file_entity.html#a5d65c32eb48e91d0b0ce808849d3238e',1,'Class.ITextFileEntity.GetReadLock'],['../class_class_1_1_text_file_entity.html#a624e8ada5a11631cf905d3f9606643bd',1,'Class.TextFileEntity.GetReadLock'],['../class_class_1_1_text_file_entity_test_double.html#aa494af569138252619e3f48770e497a2',1,'Class.TextFileEntityTestDouble.GetReadLock']]],
  ['getwritelock_1',['GetWriteLock',['../interface_class_1_1_i_text_file_entity.html#afd38dce2f6007e3d87e801b0a459346f',1,'Class.ITextFileEntity.GetWriteLock'],['../class_class_1_1_text_file_entity.html#a7f0c9f05ad242f35cc9c036dcd72bf74',1,'Class.TextFileEntity.GetWriteLock'],['../class_class_1_1_text_file_entity_test_double.html#a02e5fbaeae0a1adfa0417b051fa5d084',1,'Class.TextFileEntityTestDouble.GetWriteLock']]]
];
