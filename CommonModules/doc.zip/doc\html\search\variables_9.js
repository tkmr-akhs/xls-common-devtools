var searchData=
[
  ['movedirectory_5fresults_0',['MoveDirectory_Results',['../class_class_1_1_file_system_service_test_double.html#a52fc8f06597aa5259e1ee2edf9d73242',1,'Class::FileSystemServiceTestDouble']]],
  ['movefile_5fresults_1',['MoveFile_Results',['../class_class_1_1_file_system_service_test_double.html#a1fe6bea7451baae5e066ccdd86ccd3a5',1,'Class::FileSystemServiceTestDouble']]]
];
