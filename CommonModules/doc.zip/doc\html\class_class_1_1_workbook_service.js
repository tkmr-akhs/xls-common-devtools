var class_class_1_1_workbook_service =
[
    [ "GetThisWorkbookName", "class_class_1_1_workbook_service.html#a97d71053c8337d2f50277e80b9680ea7", null ],
    [ "GetThisWorkbookDirectoryPath", "class_class_1_1_workbook_service.html#ae3cc75eaffc1d0bcb353a98d096c9d90", null ],
    [ "ExistsWorkbook", "class_class_1_1_workbook_service.html#a23908a97de6ac26fe8fdc4800a39dc4b", null ],
    [ "GetAllWorkbook", "class_class_1_1_workbook_service.html#ab26fd6668949bbd1ef9c5f7348fa5535", null ],
    [ "ExistsWorksheet", "class_class_1_1_workbook_service.html#a85c9c5cfe179cd3073a77e93b7b05be5", null ],
    [ "GetAllWorksheet", "class_class_1_1_workbook_service.html#a4f3442b7d5fc3b4149e848e0e60d8fad", null ],
    [ "OpenWorkbook", "class_class_1_1_workbook_service.html#a6b91b843375a00b7f8b7a691217c4a1f", null ],
    [ "SaveWorkbook", "class_class_1_1_workbook_service.html#a2b312842d92ac74bf468b0444c87b042", null ],
    [ "IsSaved", "class_class_1_1_workbook_service.html#a8c75ec66c424dec5e75409f7e8478ca9", null ],
    [ "CloseWorkbook", "class_class_1_1_workbook_service.html#aaedd15100ba4047cb4512596692a4831", null ],
    [ "Find", "class_class_1_1_workbook_service.html#a91fdcbd93b219a1b475093463f98dca9", null ],
    [ "AddWorksheet", "class_class_1_1_workbook_service.html#a37e40e830d0da6015c0efdae48f6ef09", null ],
    [ "RemoveWorksheet", "class_class_1_1_workbook_service.html#ac35126627288a2b2ce418e1650524861", null ],
    [ "CopyWorksheet", "class_class_1_1_workbook_service.html#a54520374639199145d76d442a9f83bd1", null ],
    [ "RemoveVBComponents", "class_class_1_1_workbook_service.html#ad27a932905d32d9e7b43fd15c861a852", null ],
    [ "ActivateWorksheet", "class_class_1_1_workbook_service.html#a96718d31920fff27e0ad743b66d7d819", null ]
];