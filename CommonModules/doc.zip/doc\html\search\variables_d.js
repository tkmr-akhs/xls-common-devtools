var searchData=
[
  ['saveworkbook_5fresults_0',['SaveWorkbook_Results',['../class_class_1_1_workbook_service_test_double.html#a72330af27713a745b34a36d7689a3e99',1,'Class::WorkbookServiceTestDouble']]],
  ['setalignment_5fresults_1',['SetAlignment_Results',['../class_class_1_1_worksheet_service_test_double.html#a3698180e89820b4ae8da4a3ec352388d',1,'Class::WorksheetServiceTestDouble']]],
  ['setalldatavisible_5fresults_2',['SetAllDataVisible_Results',['../class_class_1_1_worksheet_service_test_double.html#a5878d06c19dfd32607077e4f6c979cfe',1,'Class::WorksheetServiceTestDouble']]],
  ['setrangecolor_5fresults_3',['SetRangeColor_Results',['../class_class_1_1_worksheet_service_test_double.html#a739a89522b30f0679b23da3b3316aa74',1,'Class::WorksheetServiceTestDouble']]],
  ['setsheetoutlinelevel_5fresults_4',['SetSheetOutlineLevel_Results',['../class_class_1_1_worksheet_service_test_double.html#a09b1c346d61b4d33e521d240e3790d47',1,'Class::WorksheetServiceTestDouble']]],
  ['setsheettabcolor_5fresults_5',['SetSheetTabColor_Results',['../class_class_1_1_worksheet_service_test_double.html#ad1d79157710eca301643a29b233ad9fc',1,'Class::WorksheetServiceTestDouble']]],
  ['setshrinktofit_5fresults_6',['SetShrinkToFit_Results',['../class_class_1_1_worksheet_service_test_double.html#a90034d2f0a9b5afd214bab5c16e5c072',1,'Class::WorksheetServiceTestDouble']]],
  ['setwraptext_5fresults_7',['SetWrapText_Results',['../class_class_1_1_worksheet_service_test_double.html#a0a89c022df721f9dd5fabff16025d5f4',1,'Class::WorksheetServiceTestDouble']]],
  ['sort_5fresults_8',['Sort_Results',['../class_class_1_1_worksheet_service_test_double.html#aa290021e4794c166924e75772707f0d4',1,'Class::WorksheetServiceTestDouble']]]
];
