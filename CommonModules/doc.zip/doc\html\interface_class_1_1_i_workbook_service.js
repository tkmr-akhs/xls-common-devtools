var interface_class_1_1_i_workbook_service =
[
    [ "GetThisWorkbookName", "interface_class_1_1_i_workbook_service.html#a3debb6d47f004d7515f5e9a87e377e6d", null ],
    [ "GetThisWorkbookDirectoryPath", "interface_class_1_1_i_workbook_service.html#ab9330bae3a821295fd7ff861fbfc4112", null ],
    [ "ExistsWorkbook", "interface_class_1_1_i_workbook_service.html#ad38ebd652f0dfa8d2f5c504116022587", null ],
    [ "GetAllWorkbook", "interface_class_1_1_i_workbook_service.html#a3bdf2077f58858c92110cbc4a9c27d5a", null ],
    [ "ExistsWorksheet", "interface_class_1_1_i_workbook_service.html#ab0f3e52572baf306204a9a22aa2f14f8", null ],
    [ "GetAllWorksheet", "interface_class_1_1_i_workbook_service.html#a7aa8a5215f4f573e7576a6aaf425b223", null ],
    [ "OpenWorkbook", "interface_class_1_1_i_workbook_service.html#a834f4c034d5dcd7afa724c9256a0cad7", null ],
    [ "SaveWorkbook", "interface_class_1_1_i_workbook_service.html#ad6caad48ec9f45a6a44aea6ed483b6f6", null ],
    [ "IsSaved", "interface_class_1_1_i_workbook_service.html#a465002b028ce5effb14446df378b080e", null ],
    [ "CloseWorkbook", "interface_class_1_1_i_workbook_service.html#a678dbd3a62f419597f136b0fc0f9e273", null ],
    [ "Find", "interface_class_1_1_i_workbook_service.html#a3888bebb2e2ad7570420e6f37123df72", null ],
    [ "AddWorksheet", "interface_class_1_1_i_workbook_service.html#a439517204f3fb264dad5d0b9ac9a9d4f", null ],
    [ "RemoveWorksheet", "interface_class_1_1_i_workbook_service.html#ad187ba68c6cfd9d1c828ae4ec1e0e4c2", null ],
    [ "CopyWorksheet", "interface_class_1_1_i_workbook_service.html#a0323d94fea2a8f53bb2e533fd7dfc030", null ],
    [ "ActivateWorksheet", "interface_class_1_1_i_workbook_service.html#a1687a6b8a4f13298c249d48ba1e9accd", null ],
    [ "RemoveVBComponents", "interface_class_1_1_i_workbook_service.html#abd383f541b71a3b9f76381f11076206c", null ]
];