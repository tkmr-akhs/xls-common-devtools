var class_standard_1_1_lib___text_file =
[
    [ "InitializeTextFileService", "class_standard_1_1_lib___text_file.html#a8a8b6676a79f46865ee674e6869d89eb", null ],
    [ "TfSrv", "class_standard_1_1_lib___text_file.html#ac62de185c699116f4c0e420ac3c9e23d", null ]
];