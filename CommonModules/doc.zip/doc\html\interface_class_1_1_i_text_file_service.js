var interface_class_1_1_i_text_file_service =
[
    [ "GetTextFileEntity", "interface_class_1_1_i_text_file_service.html#a3cc97ac2eaa5a3cb6abab42537e0d2c5", null ]
];