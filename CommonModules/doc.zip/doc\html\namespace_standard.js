var namespace_standard =
[
    [ "Lib_Common", "class_standard_1_1_lib___common.html", "class_standard_1_1_lib___common" ],
    [ "Lib_FileSystem", "class_standard_1_1_lib___file_system.html", "class_standard_1_1_lib___file_system" ],
    [ "Lib_IPv4", "class_standard_1_1_lib___i_pv4.html", "class_standard_1_1_lib___i_pv4" ],
    [ "Lib_TextFile", "class_standard_1_1_lib___text_file.html", "class_standard_1_1_lib___text_file" ],
    [ "Lib_UnitTest", "class_standard_1_1_lib___unit_test.html", "class_standard_1_1_lib___unit_test" ],
    [ "Test_DiffStringArray", "class_standard_1_1_test___diff_string_array.html", null ],
    [ "Test_ErrSource", "class_standard_1_1_test___err_source.html", null ],
    [ "Test_FileSystemTestDouble", "class_standard_1_1_test___file_system_test_double.html", null ],
    [ "Test_Lib_Common", "class_standard_1_1_test___lib___common.html", null ],
    [ "Test_Lib_FileSystem", "class_standard_1_1_test___lib___file_system.html", null ],
    [ "Test_Lib_TextFile", "class_standard_1_1_test___lib___text_file.html", null ],
    [ "Test_ObjectList", "class_standard_1_1_test___object_list.html", null ],
    [ "Test_TextFileEntityTestDouble", "class_standard_1_1_test___text_file_entity_test_double.html", null ],
    [ "Test_TextFileServiceTestDouble", "class_standard_1_1_test___text_file_service_test_double.html", null ],
    [ "Test_WorkbookService", "class_standard_1_1_test___workbook_service.html", null ],
    [ "Test_WorkbookServiceTestDouble", "class_standard_1_1_test___workbook_service_test_double.html", null ],
    [ "Test_WorksheetRangeBounds", "class_standard_1_1_test___worksheet_range_bounds.html", null ],
    [ "Test_WorksheetRangeBoundsEnumer", "class_standard_1_1_test___worksheet_range_bounds_enumer.html", null ],
    [ "Test_WorksheetService", "class_standard_1_1_test___worksheet_service.html", null ],
    [ "Test_WorksheetServiceTestDouble", "class_standard_1_1_test___worksheet_service_test_double.html", null ],
    [ "Tmp_ManualTest", "class_standard_1_1_tmp___manual_test.html", null ]
];