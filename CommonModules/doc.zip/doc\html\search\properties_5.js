var searchData=
[
  ['filepath_0',['FilePath',['../interface_class_1_1_i_text_file_entity.html#a4f4b43d06401bf2c41f058c4f1d8aaf8',1,'Class.ITextFileEntity.FilePath'],['../class_class_1_1_text_file_entity.html#a9e1b2ad8c85ede41de6ae387903b9e84',1,'Class.TextFileEntity.FilePath'],['../class_class_1_1_text_file_entity_test_double.html#aa2e63cf4b98f3ee2e941ad395839c793',1,'Class.TextFileEntityTestDouble.FilePath']]],
  ['finishcolumn_1',['FinishColumn',['../class_class_1_1_worksheet_range_bounds.html#aaab0848c2986cb55a8fcbd72c4706521',1,'Class::WorksheetRangeBounds']]],
  ['finishrow_2',['FinishRow',['../class_class_1_1_worksheet_range_bounds.html#a803decb97c1b6405cf5910a8265c3408',1,'Class::WorksheetRangeBounds']]]
];
