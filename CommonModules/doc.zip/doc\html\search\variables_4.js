var searchData=
[
  ['existsworkbook_5fvalues_0',['ExistsWorkbook_Values',['../class_class_1_1_workbook_service_test_double.html#a231e3e2842bdf52edd6edee1bffbfd6c',1,'Class::WorkbookServiceTestDouble']]],
  ['existsworksheet_5fvalues_1',['ExistsWorksheet_Values',['../class_class_1_1_workbook_service_test_double.html#ae30d35f77702ed6f62be52dbb42f89ae',1,'Class::WorkbookServiceTestDouble']]]
];
