var searchData=
[
  ['openfile_0',['OpenFile',['../interface_class_1_1_i_text_file_entity.html#a6d5b8afce5821583292aa95b00a80cd2',1,'Class.ITextFileEntity.OpenFile()'],['../class_class_1_1_text_file_entity.html#a7731956174c75956c1bdb2d0f568d4a2',1,'Class.TextFileEntity.OpenFile()'],['../class_class_1_1_text_file_entity_test_double.html#a35cfa83cd60bd66f19890311e15c0a5b',1,'Class.TextFileEntityTestDouble.OpenFile()']]],
  ['openworkbook_1',['OpenWorkbook',['../interface_class_1_1_i_workbook_service.html#a834f4c034d5dcd7afa724c9256a0cad7',1,'Class.IWorkbookService.OpenWorkbook()'],['../class_class_1_1_workbook_service.html#a6b91b843375a00b7f8b7a691217c4a1f',1,'Class.WorkbookService.OpenWorkbook()'],['../class_class_1_1_workbook_service_test_double.html#ac7e15248fb1effcc85f7cbcc64a27d6a',1,'Class.WorkbookServiceTestDouble.OpenWorkbook()']]]
];
