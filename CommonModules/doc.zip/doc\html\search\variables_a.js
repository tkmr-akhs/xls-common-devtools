var searchData=
[
  ['openfile_5fresults_0',['OpenFile_Results',['../class_class_1_1_text_file_entity_test_double.html#a39f71bb14d5d9e6de95bee22f85f2b52',1,'Class::TextFileEntityTestDouble']]],
  ['openworkbook_5fresults_1',['OpenWorkbook_Results',['../class_class_1_1_workbook_service_test_double.html#a7178b2d5b6fa3797e75ce16821489d82',1,'Class::WorkbookServiceTestDouble']]]
];
