var interface_class_1_1_i_text_file_entity =
[
    [ "OpenFile", "interface_class_1_1_i_text_file_entity.html#a6d5b8afce5821583292aa95b00a80cd2", null ],
    [ "ReadLine", "interface_class_1_1_i_text_file_entity.html#a73616ecde976eec6c409fb264d1268fa", null ],
    [ "WriteLine", "interface_class_1_1_i_text_file_entity.html#ab553b78626be9f85c7df7c4a3cfd16a3", null ],
    [ "CloseFile", "interface_class_1_1_i_text_file_entity.html#a324e7831cd10e72b2615c0ace4a3621c", null ],
    [ "FilePath", "interface_class_1_1_i_text_file_entity.html#a4f4b43d06401bf2c41f058c4f1d8aaf8", null ],
    [ "AsRead", "interface_class_1_1_i_text_file_entity.html#ac48d6b3185388d4768704ed5eab4aca6", null ],
    [ "AsWrite", "interface_class_1_1_i_text_file_entity.html#af3f169c8d737623fd899dd253bbc55d1", null ],
    [ "AsAppend", "interface_class_1_1_i_text_file_entity.html#a04418705eabc91de32f094c2f28d9ed6", null ],
    [ "GetReadLock", "interface_class_1_1_i_text_file_entity.html#a5d65c32eb48e91d0b0ce808849d3238e", null ],
    [ "GetWriteLock", "interface_class_1_1_i_text_file_entity.html#afd38dce2f6007e3d87e801b0a459346f", null ],
    [ "IsOpen", "interface_class_1_1_i_text_file_entity.html#a9d5969fd91bee454999ceee0c1ed17f5", null ],
    [ "IsEndOfFile", "interface_class_1_1_i_text_file_entity.html#a7719ce938297303203bcd56a49c476e0", null ]
];