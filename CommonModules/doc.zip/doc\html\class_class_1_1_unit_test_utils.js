var class_class_1_1_unit_test_utils =
[
    [ "GetValue", "class_class_1_1_unit_test_utils.html#a60aaa36cd9f2605064cd4059497f69ba", null ],
    [ "HasValue", "class_class_1_1_unit_test_utils.html#a7376d1e5050b56c60bcd43a48ccf9791", null ],
    [ "SetValue", "class_class_1_1_unit_test_utils.html#a9f008c0cf948b41d5734f4627c5b7ed4", null ]
];