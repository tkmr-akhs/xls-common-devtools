var class_class_1_1_text_file_service =
[
    [ "GetTextFileEntity", "class_class_1_1_text_file_service.html#a407b968b94b8e329309557ecf0560b6e", null ]
];