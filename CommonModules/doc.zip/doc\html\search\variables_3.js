var searchData=
[
  ['deleterows_5fresults_0',['DeleteRows_Results',['../class_class_1_1_worksheet_service_test_double.html#a8bf50fe58c42ce175597709a7b0c8760',1,'Class::WorksheetServiceTestDouble']]]
];
