var class_class_1_1_text_file_service_test_double =
[
    [ "GetTextFileEntity", "class_class_1_1_text_file_service_test_double.html#aa6f1e5af1c74f8b91dfc28b43eb0cf26", null ],
    [ "GetTextFileEntity_Values", "class_class_1_1_text_file_service_test_double.html#aca111e0add653b47388002c068d6e1b7", null ]
];