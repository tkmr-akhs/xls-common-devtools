var searchData=
[
  ['tfsrv_0',['TfSrv',['../class_standard_1_1_lib___text_file.html#ac62de185c699116f4c0e420ac3c9e23d',1,'Standard::Lib_TextFile']]]
];
