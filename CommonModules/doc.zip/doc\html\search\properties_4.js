var searchData=
[
  ['enumeratetype_0',['EnumerateType',['../class_class_1_1_worksheet_range_bounds_enumerator.html#a9cd88d1a2004cb168d7be45c5a32153d',1,'Class::WorksheetRangeBoundsEnumerator']]]
];
