var class_class_1_1_text_file_entity =
[
    [ "Initialize", "class_class_1_1_text_file_entity.html#a145267fb3bc96effd4e894f2787fc323", null ],
    [ "OpenFile", "class_class_1_1_text_file_entity.html#a7731956174c75956c1bdb2d0f568d4a2", null ],
    [ "ReadLine", "class_class_1_1_text_file_entity.html#a7d81478318b14285dc0814a4999e7257", null ],
    [ "WriteLine", "class_class_1_1_text_file_entity.html#a6345f372ee240f1a1dee0db30e80977c", null ],
    [ "CloseFile", "class_class_1_1_text_file_entity.html#ae95cb4e302773bc57263a5484feafb24", null ],
    [ "FilePath", "class_class_1_1_text_file_entity.html#a9e1b2ad8c85ede41de6ae387903b9e84", null ],
    [ "AsRead", "class_class_1_1_text_file_entity.html#a02de058d0394f6cab811ee53b1ee99b3", null ],
    [ "AsWrite", "class_class_1_1_text_file_entity.html#af9fbda09e27311eb476236160c740e2a", null ],
    [ "AsAppend", "class_class_1_1_text_file_entity.html#ae563f57c6ba0bd42c6647a3a50f36bc6", null ],
    [ "GetReadLock", "class_class_1_1_text_file_entity.html#a624e8ada5a11631cf905d3f9606643bd", null ],
    [ "GetWriteLock", "class_class_1_1_text_file_entity.html#a7f0c9f05ad242f35cc9c036dcd72bf74", null ],
    [ "IsOpen", "class_class_1_1_text_file_entity.html#a82c4123698d52415b760ec864c9080ad", null ],
    [ "IsEndOfFile", "class_class_1_1_text_file_entity.html#afe842c971a27d760f32796f574003a6c", null ]
];