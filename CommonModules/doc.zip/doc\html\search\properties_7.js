var searchData=
[
  ['index_0',['Index',['../class_class_1_1_enumerator.html#a0b5bd4cec25268951e2fdf7387f2985c',1,'Class.Enumerator.Index'],['../interface_class_1_1_i_enumerator.html#aac35e36103c7e59b16ce61acfb1ee330',1,'Class.IEnumerator.Index'],['../class_class_1_1_worksheet_range_bounds_enumerator.html#a63a30458157d023272dc4029edc134a2',1,'Class.WorksheetRangeBoundsEnumerator.Index']]],
  ['isarea_1',['IsArea',['../class_class_1_1_worksheet_range_bounds.html#ab5ad34a8f249f3acfcca542523dee2c0',1,'Class::WorksheetRangeBounds']]],
  ['iscell_2',['IsCell',['../class_class_1_1_worksheet_range_bounds.html#a4dde206adbff9318ca423d2e5bee9d8d',1,'Class::WorksheetRangeBounds']]],
  ['iscomplete_3',['IsComplete',['../class_class_1_1_progress_status.html#a5b0bce27e52de8add42566f760ec4037',1,'Class::ProgressStatus']]],
  ['isempty_4',['IsEmpty',['../class_class_1_1_worksheet_range_bounds.html#a4f15c964955f8e08104617447625b821',1,'Class::WorksheetRangeBounds']]],
  ['isendoffile_5',['IsEndOfFile',['../interface_class_1_1_i_text_file_entity.html#a7719ce938297303203bcd56a49c476e0',1,'Class.ITextFileEntity.IsEndOfFile'],['../class_class_1_1_text_file_entity.html#afe842c971a27d760f32796f574003a6c',1,'Class.TextFileEntity.IsEndOfFile'],['../class_class_1_1_text_file_entity_test_double.html#a5677aa2cb4bd90f068d06a94288d7c28',1,'Class.TextFileEntityTestDouble.IsEndOfFile']]],
  ['isentirecolumn_6',['IsEntireColumn',['../class_class_1_1_worksheet_range_bounds.html#a409e9c4e744c4d569c0257c714332b08',1,'Class::WorksheetRangeBounds']]],
  ['isentirerow_7',['IsEntireRow',['../class_class_1_1_worksheet_range_bounds.html#a563453049d3e618d1653ee040ada83ce',1,'Class::WorksheetRangeBounds']]],
  ['isentiresheet_8',['IsEntireSheet',['../class_class_1_1_worksheet_range_bounds.html#a33fd39ce5bb4b4e04f4a522268db25f8',1,'Class::WorksheetRangeBounds']]],
  ['isfailed_9',['IsFailed',['../class_class_1_1_unit_test_assert.html#a8f652f5be90c1232f7e1443fe21bd520',1,'Class::UnitTestAssert']]],
  ['isonecolumn_10',['IsOneColumn',['../class_class_1_1_worksheet_range_bounds.html#a471f0e00a3d0c0531d7fef91c912e10e',1,'Class::WorksheetRangeBounds']]],
  ['isonerow_11',['IsOneRow',['../class_class_1_1_worksheet_range_bounds.html#a34a86f85788c38fc68c7e5bcc819108a',1,'Class::WorksheetRangeBounds']]],
  ['isopen_12',['IsOpen',['../interface_class_1_1_i_text_file_entity.html#a9d5969fd91bee454999ceee0c1ed17f5',1,'Class.ITextFileEntity.IsOpen'],['../class_class_1_1_text_file_entity.html#a82c4123698d52415b760ec864c9080ad',1,'Class.TextFileEntity.IsOpen'],['../class_class_1_1_text_file_entity_test_double.html#a9f8df2920e7538937138d4faa609fe81',1,'Class.TextFileEntityTestDouble.IsOpen']]],
  ['itemtypename_13',['ItemTypeName',['../class_class_1_1_object_list.html#aed9e43cbb421cbfff2fe24983b18496e',1,'Class.ObjectList.ItemTypeName'],['../class_class_1_1_object_set.html#a8621cf058d2d50a379944e6a04461af0',1,'Class.ObjectSet.ItemTypeName']]]
];
