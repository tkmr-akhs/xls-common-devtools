var interface_class_1_1_i_equatable =
[
    [ "Equals", "interface_class_1_1_i_equatable.html#ace0006e06b4bbf29771a73c62433461e", null ],
    [ "GetIdentityString", "interface_class_1_1_i_equatable.html#a50f1a48fe6ad1fb2177d3d8f5559666e", null ]
];