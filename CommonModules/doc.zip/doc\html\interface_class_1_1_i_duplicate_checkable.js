var interface_class_1_1_i_duplicate_checkable =
[
    [ "IsDuplicateOf", "interface_class_1_1_i_duplicate_checkable.html#a2ae1315fe7a8fbbeedd47a4a7f4f1c0d", null ],
    [ "GetKey", "interface_class_1_1_i_duplicate_checkable.html#a5a8e328e98a96d743974d06252a830e1", null ]
];