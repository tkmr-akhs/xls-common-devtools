var searchData=
[
  ['bitleft_0',['BitLeft',['../class_standard_1_1_lib___common.html#a7a4980463150517e15a35bdf6af59f0e',1,'Standard::Lib_Common']]],
  ['bitright_1',['BitRight',['../class_standard_1_1_lib___common.html#a5f8a09d1206184856dd01150d55fe661',1,'Standard::Lib_Common']]],
  ['blockcount_2',['BlockCount',['../class_class_1_1_progress_status.html#a96637b7eae0ba1f9f91ff212cb27c2c2',1,'Class::ProgressStatus']]],
  ['bookcount_3',['BookCount',['../class_class_1_1_workbook_service_test_double.html#a77cf426e1e401743c2146c6b0ccfcb45',1,'Class::WorkbookServiceTestDouble']]],
  ['buildcurrentmessage_4',['BuildCurrentMessage',['../class_class_1_1_debug_information.html#a2ac63cba5e60df97a738a2ee3e8c8b65',1,'Class::DebugInformation']]],
  ['buildmessagelines_5',['BuildMessageLines',['../class_class_1_1_debug_information.html#a660a9f6f340de1cbcbe03cfcbd5a928a',1,'Class::DebugInformation']]]
];
