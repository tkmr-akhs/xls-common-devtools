var class_class_1_1_text_file_entity_test_double =
[
    [ "Initialize", "class_class_1_1_text_file_entity_test_double.html#ac9cbef1e3075bb857cbe22787df59474", null ],
    [ "OpenFile", "class_class_1_1_text_file_entity_test_double.html#a35cfa83cd60bd66f19890311e15c0a5b", null ],
    [ "ReadLine", "class_class_1_1_text_file_entity_test_double.html#a89564c78261bbb5cb11d1d3ee8860f2a", null ],
    [ "WriteLine", "class_class_1_1_text_file_entity_test_double.html#a2aca5efbe718984104b0e2b59ecbe6c4", null ],
    [ "CloseFile", "class_class_1_1_text_file_entity_test_double.html#ad18213a2332326ef05a430d3bac9fb1c", null ],
    [ "ReadCount", "class_class_1_1_text_file_entity_test_double.html#a3dbfec935f26cb28a29c52722eaec5b1", null ],
    [ "WriteCount", "class_class_1_1_text_file_entity_test_double.html#aeac3d8bb262604b4a17e14e51a261d40", null ],
    [ "Initialize_Results", "class_class_1_1_text_file_entity_test_double.html#a8ba822d8f1968391ea54de1715cc4699", null ],
    [ "OpenFile_Results", "class_class_1_1_text_file_entity_test_double.html#a39f71bb14d5d9e6de95bee22f85f2b52", null ],
    [ "WriteLine_Results", "class_class_1_1_text_file_entity_test_double.html#acb68ec8ef4c1b99b6ad4cd2dc8b9d878", null ],
    [ "ReadLine_Values", "class_class_1_1_text_file_entity_test_double.html#af4dae48de18b03f26924824fadf7f824", null ],
    [ "CloseFile_Results", "class_class_1_1_text_file_entity_test_double.html#a5e1d310c93bf81a45c61511527a0dfde", null ],
    [ "FilePath", "class_class_1_1_text_file_entity_test_double.html#aa2e63cf4b98f3ee2e941ad395839c793", null ],
    [ "AsRead", "class_class_1_1_text_file_entity_test_double.html#aa87ff77810b91137b416fde14baaf8ac", null ],
    [ "AsWrite", "class_class_1_1_text_file_entity_test_double.html#ad249dc97621397ed8e6126e37dc06067", null ],
    [ "AsAppend", "class_class_1_1_text_file_entity_test_double.html#ad881fe5afacf9d074b42eec09d78d392", null ],
    [ "GetReadLock", "class_class_1_1_text_file_entity_test_double.html#aa494af569138252619e3f48770e497a2", null ],
    [ "GetWriteLock", "class_class_1_1_text_file_entity_test_double.html#a02e5fbaeae0a1adfa0417b051fa5d084", null ],
    [ "IsOpen", "class_class_1_1_text_file_entity_test_double.html#a9f8df2920e7538937138d4faa609fe81", null ],
    [ "IsEndOfFile", "class_class_1_1_text_file_entity_test_double.html#a5677aa2cb4bd90f068d06a94288d7c28", null ]
];