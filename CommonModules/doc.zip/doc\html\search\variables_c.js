var searchData=
[
  ['readcell_5fvalues_0',['ReadCell_Values',['../class_class_1_1_worksheet_service_test_double.html#ac21e5794a087f4ab70f5d19609a7e968',1,'Class::WorksheetServiceTestDouble']]],
  ['readcount_1',['ReadCount',['../class_class_1_1_text_file_entity_test_double.html#a3dbfec935f26cb28a29c52722eaec5b1',1,'Class::TextFileEntityTestDouble']]],
  ['readline_5fvalues_2',['ReadLine_Values',['../class_class_1_1_text_file_entity_test_double.html#af4dae48de18b03f26924824fadf7f824',1,'Class::TextFileEntityTestDouble']]],
  ['readrange_5fvalues_3',['ReadRange_Values',['../class_class_1_1_worksheet_service_test_double.html#acb9b7724a4ef06d0619227d3a83e1b43',1,'Class::WorksheetServiceTestDouble']]],
  ['removedirectory_5fresults_4',['RemoveDirectory_Results',['../class_class_1_1_file_system_service_test_double.html#a7b0bc937e694be44c159201765030e36',1,'Class::FileSystemServiceTestDouble']]],
  ['removedirectory_5fvalues_5',['RemoveDirectory_Values',['../class_class_1_1_file_system_service_test_double.html#a34debd5c7766ee7c00f79fdcba375a30',1,'Class::FileSystemServiceTestDouble']]],
  ['removeduplicates_5fresults_6',['RemoveDuplicates_Results',['../class_class_1_1_worksheet_service_test_double.html#a4d138ca5d1355c01b3c3855c46e0649c',1,'Class::WorksheetServiceTestDouble']]],
  ['removefile_5fresults_7',['RemoveFile_Results',['../class_class_1_1_file_system_service_test_double.html#a534bac513b63da945de91bbb882ae5fa',1,'Class::FileSystemServiceTestDouble']]],
  ['removefile_5fvalues_8',['RemoveFile_Values',['../class_class_1_1_file_system_service_test_double.html#a95bfbd9fa833addbda46c7be8b36f0d3',1,'Class::FileSystemServiceTestDouble']]],
  ['removevbcomponents_5fresults_9',['RemoveVBComponents_Results',['../class_class_1_1_workbook_service_test_double.html#a50540ea82e442c1451986ed6cb785699',1,'Class::WorkbookServiceTestDouble']]],
  ['removeworksheet_5fresults_10',['RemoveWorksheet_Results',['../class_class_1_1_workbook_service_test_double.html#a5ee616bf59110de664b1fb55a0cce88e',1,'Class::WorkbookServiceTestDouble']]]
];
