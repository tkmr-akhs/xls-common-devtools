var class_class_1_1_counter =
[
    [ "Initialize", "class_class_1_1_counter.html#aee3989e150f5f424d2642a668931e7e2", null ],
    [ "HasNext", "class_class_1_1_counter.html#a2d2f139ece5b7e3d1f7c7a2de31959fa", null ],
    [ "GoNext", "class_class_1_1_counter.html#a2ac9bb19e92747ac56933f2be0c26654", null ],
    [ "Count", "class_class_1_1_counter.html#aad0612f5bb3bdb37834925102cdda217", null ],
    [ "CountStep", "class_class_1_1_counter.html#acb1c4b85f8aa13d1cf954049884e1556", null ],
    [ "StopWhenMax", "class_class_1_1_counter.html#a213b9b50027e2658ed35a55b23c33b4b", null ],
    [ "MaxCount", "class_class_1_1_counter.html#ac8fa056b6796d9eeca2823f0cb07db9d", null ]
];