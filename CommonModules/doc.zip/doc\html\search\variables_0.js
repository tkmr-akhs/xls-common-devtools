var searchData=
[
  ['activaterange_5fresults_0',['ActivateRange_Results',['../class_class_1_1_worksheet_service_test_double.html#a7f8ceb978af86eda77c6d9f57003ec61',1,'Class::WorksheetServiceTestDouble']]],
  ['activateworksheet_5fresults_1',['ActivateWorksheet_Results',['../class_class_1_1_workbook_service_test_double.html#a1f60a0a8f6dff1ecc59e267f182999c1',1,'Class::WorkbookServiceTestDouble']]],
  ['addsheetcount_2',['AddSheetCount',['../class_class_1_1_workbook_service_test_double.html#a9b550236623121a9c7a60b1cdc1a8047',1,'Class::WorkbookServiceTestDouble']]],
  ['addworksheet_5fresults_3',['AddWorksheet_Results',['../class_class_1_1_workbook_service_test_double.html#aef3ea0c730152a91ab0d48dade7e8056',1,'Class::WorkbookServiceTestDouble']]]
];
