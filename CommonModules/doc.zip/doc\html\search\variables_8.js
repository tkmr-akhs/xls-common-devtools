var searchData=
[
  ['initialize_5fresults_0',['Initialize_Results',['../class_class_1_1_text_file_entity_test_double.html#a8ba822d8f1968391ea54de1715cc4699',1,'Class::TextFileEntityTestDouble']]],
  ['insertrows_5fresults_1',['InsertRows_Results',['../class_class_1_1_worksheet_service_test_double.html#af19594f0b515f307160414e84659dc95',1,'Class::WorksheetServiceTestDouble']]],
  ['isdirectory_5fvalues_2',['IsDirectory_Values',['../class_class_1_1_file_system_service_test_double.html#ab01ceee088a6ab24463aa5d0538e08af',1,'Class::FileSystemServiceTestDouble']]],
  ['isemptycell_5fvalues_3',['IsEmptyCell_Values',['../class_class_1_1_worksheet_service_test_double.html#ad08bccf3a1d28dcd868cba71d94647f1',1,'Class::WorksheetServiceTestDouble']]],
  ['isfile_5fvalues_4',['IsFile_Values',['../class_class_1_1_file_system_service_test_double.html#a4a238aeb006764815a21f0eb6b8abf7f',1,'Class::FileSystemServiceTestDouble']]],
  ['issaved_5fvalues_5',['IsSaved_Values',['../class_class_1_1_workbook_service_test_double.html#aa00aa277933c8ca492b14f7c1e1fcda9',1,'Class::WorkbookServiceTestDouble']]]
];
