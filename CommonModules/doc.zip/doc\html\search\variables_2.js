var searchData=
[
  ['clearrange_5fresults_0',['ClearRange_Results',['../class_class_1_1_worksheet_service_test_double.html#ab73690ba43701545bd4af5560b737f99',1,'Class::WorksheetServiceTestDouble']]],
  ['closefile_5fresults_1',['CloseFile_Results',['../class_class_1_1_text_file_entity_test_double.html#a5e1d310c93bf81a45c61511527a0dfde',1,'Class::TextFileEntityTestDouble']]],
  ['coloseworkbook_5fresults_2',['ColoseWorkbook_Results',['../class_class_1_1_workbook_service_test_double.html#a4a6cc02cba105df1f310e3c776af39b5',1,'Class::WorkbookServiceTestDouble']]],
  ['copycell_5fresults_3',['CopyCell_Results',['../class_class_1_1_worksheet_service_test_double.html#ad7dc5b1464650e92f3086e88804eed1b',1,'Class::WorksheetServiceTestDouble']]],
  ['copydirectory_5fresults_4',['CopyDirectory_Results',['../class_class_1_1_file_system_service_test_double.html#a3f3768d059355b78388f9083e0859e43',1,'Class::FileSystemServiceTestDouble']]],
  ['copyfile_5fresults_5',['CopyFile_Results',['../class_class_1_1_file_system_service_test_double.html#a431ea80357edecdf4c24167f33acef74',1,'Class::FileSystemServiceTestDouble']]],
  ['copyrange_5fresults_6',['CopyRange_Results',['../class_class_1_1_worksheet_service_test_double.html#a091552d61727a4e1ef2ba54a1fc76ad2',1,'Class::WorksheetServiceTestDouble']]],
  ['copysheetcount_7',['CopySheetCount',['../class_class_1_1_workbook_service_test_double.html#abcd546718d306d0c5c137653bc6dc3c8',1,'Class::WorkbookServiceTestDouble']]],
  ['copyworksheet_5fresults_8',['CopyWorksheet_Results',['../class_class_1_1_workbook_service_test_double.html#a184631c4895d093522acadefff6f7a58',1,'Class::WorkbookServiceTestDouble']]],
  ['createbackupfile_5fresults_9',['CreateBackupFile_Results',['../class_class_1_1_file_system_service_test_double.html#a1dbd6e34792a8e206a740ae8ba76a17a',1,'Class::FileSystemServiceTestDouble']]],
  ['createbackupfile_5fvalues_10',['CreateBackupFile_Values',['../class_class_1_1_file_system_service_test_double.html#a1b1d9b8b39c10603766c5301a0d83114',1,'Class::FileSystemServiceTestDouble']]],
  ['createdirectory_5fresults_11',['CreateDirectory_Results',['../class_class_1_1_file_system_service_test_double.html#a7caf5b5207019a0be2115a7356224c85',1,'Class::FileSystemServiceTestDouble']]],
  ['createdirectory_5fvalues_12',['CreateDirectory_Values',['../class_class_1_1_file_system_service_test_double.html#a19752162d057f68699cef6579c8e714a',1,'Class::FileSystemServiceTestDouble']]]
];
