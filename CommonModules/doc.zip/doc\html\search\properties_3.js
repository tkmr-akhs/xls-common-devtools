var searchData=
[
  ['descending_0',['Descending',['../class_class_1_1_enumerator.html#ab00a87d1421133037e235f0f9f5c5356',1,'Class.Enumerator.Descending'],['../class_class_1_1_worksheet_range_bounds_enumerator.html#a66796e4582aa396b0d70b58ec1658d2b',1,'Class.WorksheetRangeBoundsEnumerator.Descending']]]
];
