var searchData=
[
  ['bookcount_0',['BookCount',['../class_class_1_1_workbook_service_test_double.html#a77cf426e1e401743c2146c6b0ccfcb45',1,'Class::WorkbookServiceTestDouble']]]
];
