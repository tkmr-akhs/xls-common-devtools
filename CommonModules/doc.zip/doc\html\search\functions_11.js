var searchData=
[
  ['tostring_0',['ToString',['../interface_class_1_1_i_stringable.html#a7cb047cc2dc2dd11e07109c7081e60dc',1,'Class.IStringable.ToString()'],['../class_class_1_1_worksheet_range_bounds.html#a8029af132ae5cf2e621f1e3270ba29d8',1,'Class.WorksheetRangeBounds.ToString(Boolean IsAbsoluteStartRow=False, Boolean IsAbsoluteStartColumn=False, Boolean IsAbsoluteFinishRow=False, Boolean IsAbsoluteFinishColumn=False, String AddressType=&quot;A1&quot;, Boolean CellOnly=False)']]],
  ['transform_1',['Transform',['../class_class_1_1_worksheet_range_bounds.html#a3c60de3e077f4c06a541f6a18f955b8e',1,'Class::WorksheetRangeBounds']]],
  ['transformabsolute_2',['TransformAbsolute',['../class_class_1_1_worksheet_range_bounds.html#af579539500b73cb7908fa4975bedb290',1,'Class::WorksheetRangeBounds']]]
];
