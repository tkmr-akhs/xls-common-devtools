var searchData=
[
  ['objectlist_0',['ObjectList',['../class_class_1_1_object_list.html',1,'Class']]],
  ['objectset_1',['ObjectSet',['../class_class_1_1_object_set.html',1,'Class']]],
  ['openfile_2',['OpenFile',['../interface_class_1_1_i_text_file_entity.html#a6d5b8afce5821583292aa95b00a80cd2',1,'Class.ITextFileEntity.OpenFile()'],['../class_class_1_1_text_file_entity.html#a7731956174c75956c1bdb2d0f568d4a2',1,'Class.TextFileEntity.OpenFile()'],['../class_class_1_1_text_file_entity_test_double.html#a35cfa83cd60bd66f19890311e15c0a5b',1,'Class.TextFileEntityTestDouble.OpenFile(Boolean AsWrite=False, Boolean AsAppend=False, Boolean GetReadLock=False, Boolean GetWriteLock=False, Boolean Force=default)']]],
  ['openfile_5fresults_3',['OpenFile_Results',['../class_class_1_1_text_file_entity_test_double.html#a39f71bb14d5d9e6de95bee22f85f2b52',1,'Class::TextFileEntityTestDouble']]],
  ['openworkbook_4',['OpenWorkbook',['../interface_class_1_1_i_workbook_service.html#a834f4c034d5dcd7afa724c9256a0cad7',1,'Class.IWorkbookService.OpenWorkbook()'],['../class_class_1_1_workbook_service.html#a6b91b843375a00b7f8b7a691217c4a1f',1,'Class.WorkbookService.OpenWorkbook()'],['../class_class_1_1_workbook_service_test_double.html#ac7e15248fb1effcc85f7cbcc64a27d6a',1,'Class.WorkbookServiceTestDouble.OpenWorkbook(String FilePath=default)']]],
  ['openworkbook_5fresults_5',['OpenWorkbook_Results',['../class_class_1_1_workbook_service_test_double.html#a7178b2d5b6fa3797e75ce16821489d82',1,'Class::WorkbookServiceTestDouble']]]
];
