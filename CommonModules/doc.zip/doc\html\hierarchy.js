var hierarchy =
[
    [ "Class.ApplicationScreenUpdateManager", "class_class_1_1_application_screen_update_manager.html", null ],
    [ "Class.ArrayObject", "class_class_1_1_array_object.html", null ],
    [ "Class.Counter", "class_class_1_1_counter.html", null ],
    [ "Class.CounterSet", "class_class_1_1_counter_set.html", null ],
    [ "Class.DebugInformation", "class_class_1_1_debug_information.html", null ],
    [ "Class.IComparable", "interface_class_1_1_i_comparable.html", null ],
    [ "Class.IDuplicateCheckable", "interface_class_1_1_i_duplicate_checkable.html", null ],
    [ "Class.IEnumerator", "interface_class_1_1_i_enumerator.html", [
      [ "Class.Enumerator", "class_class_1_1_enumerator.html", null ],
      [ "Class.WorksheetRangeBoundsEnumerator", "class_class_1_1_worksheet_range_bounds_enumerator.html", null ]
    ] ],
    [ "Class.IEquatable", "interface_class_1_1_i_equatable.html", null ],
    [ "Class.IFileSystemService", "interface_class_1_1_i_file_system_service.html", [
      [ "Class.FileSystemService", "class_class_1_1_file_system_service.html", null ],
      [ "Class.FileSystemServiceTestDouble", "class_class_1_1_file_system_service_test_double.html", null ]
    ] ],
    [ "Class.IStringable", "interface_class_1_1_i_stringable.html", [
      [ "Class.WorksheetRangeBounds", "class_class_1_1_worksheet_range_bounds.html", null ]
    ] ],
    [ "Class.ITextFileEntity", "interface_class_1_1_i_text_file_entity.html", [
      [ "Class.TextFileEntity", "class_class_1_1_text_file_entity.html", null ],
      [ "Class.TextFileEntityTestDouble", "class_class_1_1_text_file_entity_test_double.html", null ]
    ] ],
    [ "Class.ITextFileService", "interface_class_1_1_i_text_file_service.html", [
      [ "Class.TextFileService", "class_class_1_1_text_file_service.html", null ],
      [ "Class.TextFileServiceTestDouble", "class_class_1_1_text_file_service_test_double.html", null ]
    ] ],
    [ "Class.IWorkbookService", "interface_class_1_1_i_workbook_service.html", [
      [ "Class.WorkbookService", "class_class_1_1_workbook_service.html", null ],
      [ "Class.WorkbookServiceTestDouble", "class_class_1_1_workbook_service_test_double.html", null ]
    ] ],
    [ "Class.IWorksheetService", "interface_class_1_1_i_worksheet_service.html", [
      [ "Class.WorksheetService", "class_class_1_1_worksheet_service.html", null ],
      [ "Class.WorksheetServiceTestDouble", "class_class_1_1_worksheet_service_test_double.html", null ]
    ] ],
    [ "Standard.Lib_Common", "class_standard_1_1_lib___common.html", null ],
    [ "Standard.Lib_FileSystem", "class_standard_1_1_lib___file_system.html", null ],
    [ "Standard.Lib_IPv4", "class_standard_1_1_lib___i_pv4.html", null ],
    [ "Standard.Lib_TextFile", "class_standard_1_1_lib___text_file.html", null ],
    [ "Standard.Lib_UnitTest", "class_standard_1_1_lib___unit_test.html", null ],
    [ "Class.ObjectList", "class_class_1_1_object_list.html", null ],
    [ "Class.ObjectSet", "class_class_1_1_object_set.html", null ],
    [ "Class.ProgressStatus", "class_class_1_1_progress_status.html", null ],
    [ "Standard.Test_DiffStringArray", "class_standard_1_1_test___diff_string_array.html", null ],
    [ "Standard.Test_ErrSource", "class_standard_1_1_test___err_source.html", null ],
    [ "Standard.Test_FileSystemTestDouble", "class_standard_1_1_test___file_system_test_double.html", null ],
    [ "Standard.Test_Lib_Common", "class_standard_1_1_test___lib___common.html", null ],
    [ "Standard.Test_Lib_FileSystem", "class_standard_1_1_test___lib___file_system.html", null ],
    [ "Standard.Test_Lib_TextFile", "class_standard_1_1_test___lib___text_file.html", null ],
    [ "Standard.Test_ObjectList", "class_standard_1_1_test___object_list.html", null ],
    [ "Standard.Test_TextFileEntityTestDouble", "class_standard_1_1_test___text_file_entity_test_double.html", null ],
    [ "Standard.Test_TextFileServiceTestDouble", "class_standard_1_1_test___text_file_service_test_double.html", null ],
    [ "Standard.Test_WorkbookService", "class_standard_1_1_test___workbook_service.html", null ],
    [ "Standard.Test_WorkbookServiceTestDouble", "class_standard_1_1_test___workbook_service_test_double.html", null ],
    [ "Standard.Test_WorksheetRangeBounds", "class_standard_1_1_test___worksheet_range_bounds.html", null ],
    [ "Standard.Test_WorksheetRangeBoundsEnumer", "class_standard_1_1_test___worksheet_range_bounds_enumer.html", null ],
    [ "Standard.Test_WorksheetService", "class_standard_1_1_test___worksheet_service.html", null ],
    [ "Standard.Test_WorksheetServiceTestDouble", "class_standard_1_1_test___worksheet_service_test_double.html", null ],
    [ "Standard.Tmp_ManualTest", "class_standard_1_1_tmp___manual_test.html", null ],
    [ "Class.UnitTestAssert", "class_class_1_1_unit_test_assert.html", null ],
    [ "Class.UnitTestUtils", "class_class_1_1_unit_test_utils.html", null ],
    [ "Class.UserInputSheet", "class_class_1_1_user_input_sheet.html", null ]
];