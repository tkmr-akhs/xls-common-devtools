var searchData=
[
  ['icomparable_0',['IComparable',['../interface_class_1_1_i_comparable.html',1,'Class']]],
  ['iduplicatecheckable_1',['IDuplicateCheckable',['../interface_class_1_1_i_duplicate_checkable.html',1,'Class']]],
  ['ienumerator_2',['IEnumerator',['../interface_class_1_1_i_enumerator.html',1,'Class']]],
  ['iequatable_3',['IEquatable',['../interface_class_1_1_i_equatable.html',1,'Class']]],
  ['ifilesystemservice_4',['IFileSystemService',['../interface_class_1_1_i_file_system_service.html',1,'Class']]],
  ['istringable_5',['IStringable',['../interface_class_1_1_i_stringable.html',1,'Class']]],
  ['itextfileentity_6',['ITextFileEntity',['../interface_class_1_1_i_text_file_entity.html',1,'Class']]],
  ['itextfileservice_7',['ITextFileService',['../interface_class_1_1_i_text_file_service.html',1,'Class']]],
  ['iworkbookservice_8',['IWorkbookService',['../interface_class_1_1_i_workbook_service.html',1,'Class']]],
  ['iworksheetservice_9',['IWorksheetService',['../interface_class_1_1_i_worksheet_service.html',1,'Class']]]
];
